#include <array>
#include <iostream>
#include <string>
using namespace std;

int main()
{
    array<string, 10> nombres       = {"Juan", "Maria"};
    array<int, 10>    nacimientos   = {2000, 2005};
    array<double, 10> gpas          = {3.4, 2.8};
    for (int i = 2; i <= 3; i++)
    {
        cout << "Estudiante " << i + 1 << endl;
        cout << "Nombre: ";
        cin >> nombres.at(i);
        cout << "Año de nacimiento: ";
        cin >> nacimientos.at(i);
        cout << "GPA: ";
        cin >> gpas.at(i);
    }

    cout << "\nElementos insertados:" << endl;
    for (int i = 2; i <= 3; i++)
        cout << nombres[i] << " " << nacimientos[i] << " " << gpas[i] << endl;

    return 0;
}
