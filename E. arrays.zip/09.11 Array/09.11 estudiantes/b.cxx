#include <array>
#include <iostream>
#include <string>
using namespace std;

int main()
{
    array<string, 10> nombres       = {"Juan", "Maria"};
    array<int, 10>    nacimientos   = {2000, 2005};
    array<double, 10> gpas          = {3.4, 2.8};

    string nom[] = {"Gaby", "Patty", "Diana"};
    int    nac[] = {2002, 2004, 2006};
    double gp[]  = {3.8, 3.0, 2.9};

    for (int i = 0; i < 2; i++)
    {
        nombres[4 + i]     = nom[i];
        nacimientos[4 + i] = nac[i];
        gpas[4 + i]        = gp[i];
    }

    for (int i = 4; i <= 5; i++)
        cout << nombres[i] << " " << nacimientos[i] << " " << gpas[i] << endl;

    return 0;
}