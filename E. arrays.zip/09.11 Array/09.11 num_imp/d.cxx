#include <array>
#include <algorithm>
#include <iostream>
using namespace std;

int main()
{
    array<int, 20> numeros = {
        41, 29, 37, 23, 47,
        71, 53, 95, 61, 57, 89, 67, 77, 59, 83,
        13, 3, 19, 7, 15
    };

    sort(numeros.begin(), numeros.end());
    for (size_t i = 1; i < 10; i += 2)
        cout << "indice " << i << ": " << numeros[i] << endl;

    return 0;
}