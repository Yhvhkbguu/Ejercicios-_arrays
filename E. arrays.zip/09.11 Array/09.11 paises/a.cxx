#include <array>
#include <iostream>
#include <string>
using namespace std;

int main()
{
   
    array<string, 12> paises = {
        "Argentina", "Bolivia", "Brasil", "Chile", "Colombia",
        "Ecuador", "Guyana", "Paraguay", "Peru", "Surinam"
    };

    paises.at(10) = "Uruguay";     
    paises[11]    = "Venezuela"; 
    for (const auto& p : paises)
        cout << p << endl;

    return 0;
}
