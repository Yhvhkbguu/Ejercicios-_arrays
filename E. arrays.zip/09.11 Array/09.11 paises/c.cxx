#include <array>
#include <iostream>
#include <string>
using namespace std;

int main()
{
    array<string, 12> paises = {
        "Argentina", "Bolivia", "Brasil", "Chile", "Colombia",
        "Ecuador", "Guyana", "Paraguay", "Peru", "Surinam"
    };
    paises.at(10) = "Uruguay";
    paises[11]    = "Venezuela";

    cout << " Primer elemento: " << paises.front() << endl;
    cout << "   Ultimo elemento: " << paises.back() << endl;

    return 0;
}